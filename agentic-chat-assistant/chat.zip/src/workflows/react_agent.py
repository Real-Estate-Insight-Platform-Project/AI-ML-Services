"""
LangGraph ReAct Agent Workflow
Orchestrates tool usage with reasoning and acting pattern
"""
import json
from typing import Dict, List, Any, TypedDict, Annotated, Sequence
import operator
from datetime import datetime

from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolExecutor
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_google_genai import ChatGoogleGenerativeAI
import structlog

from src.config import settings
from src.tools.tools import TOOLS
from src.agents.supabase_domain import SUPABASE_DOMAIN_KNOWLEDGE
from src.agents.bigquery_domain import BIGQUERY_DOMAIN_KNOWLEDGE

logger = structlog.get_logger()


# ==================== STATE DEFINITION ====================

class AgentState(TypedDict):
    """State for the ReAct agent workflow"""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    user_query: str
    session_id: str
    intent: str
    requires_sql: bool
    requires_geocoding: bool
    requires_web_search: bool
    context: Dict[str, Any]
    iteration_count: int
    max_iterations: int


# ==================== INTENT CLASSIFICATION ====================

class IntentClassifier:
    """Classify user intent using Gemini 2.5 Flash"""
    
    def __init__(self):
        self.model = ChatGoogleGenerativeAI(
            model=settings.gemini_flash_model,
            temperature=0.1,
            google_api_key=settings.google_api_key
        )
        
        self.intent_prompt = """You are an intent classifier for a real estate assistant.

Analyze the user query and classify it into one or more categories:

**Intents:**
1. PROPERTY_SEARCH - User wants to find properties
2. MARKET_ANALYSIS - User wants market statistics, trends, or predictions
3. INVESTMENT_ADVICE - User wants investment recommendations
4. RISK_ASSESSMENT - User wants disaster risk or safety information
5. LOCATION_BASED - User mentions specific locations that may need geocoding
6. AGENT_FINDER - User wants real estate agent recommendations
7. WEB_SEARCH - User asks about current events or information not in database
8. GENERAL_CHAT - General questions about real estate

**SQL Requirements:**
- supabase_sql: Needs property listings, risk data, or ZIP codes
- bigquery_sql: Needs market statistics, trends, or predictions
- both_sql: Needs both Supabase and BigQuery data

**Additional Flags:**
- requires_geocoding: Query mentions places that need coordinates (universities, landmarks, addresses)
- requires_web_search: Query about current news, recent events, or external information

Respond with JSON:
{
  "primary_intent": "INTENT_NAME",
  "secondary_intents": ["INTENT_NAME", ...],
  "requires_supabase_sql": true/false,
  "requires_bigquery_sql": true/false,
  "requires_geocoding": true/false,
  "requires_web_search": true/false,
  "reasoning": "brief explanation"
}

User Query: {query}"""
    
    def classify(self, query: str) -> Dict[str, Any]:
        """Classify user intent"""
        try:
            prompt = self.intent_prompt.format(query=query)
            response = self.model.invoke([HumanMessage(content=prompt)])
            
            # Extract JSON from response
            content = response.content
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]
            
            intent_data = json.loads(content.strip())
            logger.info("intent_classified", query=query, intent=intent_data)
            
            return intent_data
            
        except Exception as e:
            logger.error("intent_classification_error", error=str(e))
            # Fallback to basic classification
            return {
                "primary_intent": "GENERAL_CHAT",
                "secondary_intents": [],
                "requires_supabase_sql": False,
                "requires_bigquery_sql": False,
                "requires_geocoding": False,
                "requires_web_search": False,
                "reasoning": "Fallback classification due to error"
            }


# ==================== AGENT NODES ====================

class ReActAgent:
    """ReAct (Reasoning + Acting) Agent with LangGraph"""
    
    def __init__(self):
        self.intent_classifier = IntentClassifier()
        
        # Main reasoning model (Gemini Flash for complex reasoning)
        self.reasoning_model = ChatGoogleGenerativeAI(
            model=settings.gemini_flash_model,
            temperature=0.3,
            google_api_key=settings.google_api_key
        ).bind_tools(TOOLS)
        
        # Response formatting model (Gemini Flash for speed)
        self.formatter_model = ChatGoogleGenerativeAI(
            model=settings.gemini_flash_model,
            temperature=0.5,
            google_api_key=settings.google_api_key
        )
        
        self.tool_executor = ToolExecutor(TOOLS)
        
        # Build workflow
        self.workflow = self._build_workflow()
        self.app = self.workflow.compile()
    
    def _build_workflow(self) -> StateGraph:
        """Build the LangGraph workflow"""
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("classify_intent", self.classify_intent_node)
        workflow.add_node("reason", self.reason_node)
        workflow.add_node("act", self.act_node)
        workflow.add_node("format_response", self.format_response_node)
        
        # Add edges
        workflow.set_entry_point("classify_intent")
        workflow.add_edge("classify_intent", "reason")
        workflow.add_conditional_edges(
            "reason",
            self.should_continue,
            {
                "continue": "act",
                "end": "format_response"
            }
        )
        workflow.add_edge("act", "reason")
        workflow.add_edge("format_response", END)
        
        return workflow
    
    def classify_intent_node(self, state: AgentState) -> AgentState:
        """Classify user intent"""
        query = state["user_query"]
        intent_data = self.intent_classifier.classify(query)
        
        state["intent"] = intent_data.get("primary_intent", "GENERAL_CHAT")
        state["requires_sql"] = (
            intent_data.get("requires_supabase_sql", False) or
            intent_data.get("requires_bigquery_sql", False)
        )
        state["requires_geocoding"] = intent_data.get("requires_geocoding", False)
        state["requires_web_search"] = intent_data.get("requires_web_search", False)
        state["context"]["intent_analysis"] = intent_data
        
        logger.info("intent_classified", 
                   intent=state["intent"],
                   requires_sql=state["requires_sql"],
                   requires_geocoding=state["requires_geocoding"])
        
        return state
    
    def reason_node(self, state: AgentState) -> AgentState:
        """Reasoning node - decide what action to take"""
        messages = state["messages"]
        
        # Add system context based on intent
        system_message = self._build_system_message(state)
        messages_with_system = [system_message] + list(messages)
        
        # Get model response (may include tool calls)
        response = self.reasoning_model.invoke(messages_with_system)
        
        state["messages"] = state["messages"] + [response]
        state["iteration_count"] = state.get("iteration_count", 0) + 1
        
        logger.info("reasoning_step", 
                   iteration=state["iteration_count"],
                   has_tool_calls=bool(response.tool_calls))
        
        return state
    
    def act_node(self, state: AgentState) -> AgentState:
        """Action node - execute tools"""
        last_message = state["messages"][-1]
        
        tool_outputs = []
        for tool_call in last_message.tool_calls:
            try:
                tool_name = tool_call["name"]
                tool_args = tool_call["args"]
                
                logger.info("executing_tool", tool=tool_name, args=tool_args)
                
                # Execute tool
                output = self.tool_executor.invoke(tool_call)
                
                tool_outputs.append(
                    ToolMessage(
                        content=json.dumps(output),
                        tool_call_id=tool_call["id"]
                    )
                )
                
                logger.info("tool_executed", tool=tool_name, success=True)
                
            except Exception as e:
                logger.error("tool_execution_error", tool=tool_name, error=str(e))
                tool_outputs.append(
                    ToolMessage(
                        content=json.dumps({"error": str(e), "success": False}),
                        tool_call_id=tool_call["id"]
                    )
                )
        
        state["messages"] = state["messages"] + tool_outputs
        return state
    
    def format_response_node(self, state: AgentState) -> AgentState:
        """Format final response for user"""
        messages = state["messages"]
        
        # Build formatting prompt
        format_prompt = """You are a helpful real estate assistant. Format the conversation results into a clear, user-friendly response.

Guidelines:
1. Start with a concise summary answering the user's question
2. Present key information using clear formatting:
   - Use **bold** for important numbers and names
   - Use bullet points for lists
   - Include relevant details like prices, locations, dates
3. For properties: Include address, price, beds/baths, key features
4. For market data: Include trends, predictions, and context
5. For investment advice: Include risks, opportunities, and recommendations
6. Always be conversational and helpful
7. If recommending agents, direct to: {agent_finder_url}
8. End with a helpful follow-up question if appropriate

Previous conversation:
{conversation}

Format this into a clear, engaging response for the user:"""
        
        # Get conversation context
        conversation = "\n".join([
            f"{msg.__class__.__name__}: {msg.content[:500]}..." 
            if len(str(msg.content)) > 500 else f"{msg.__class__.__name__}: {msg.content}"
            for msg in messages[-5:]
        ])
        
        prompt = format_prompt.format(
            conversation=conversation,
            agent_finder_url=settings.agent_finder_url
        )
        
        formatted_response = self.formatter_model.invoke([HumanMessage(content=prompt)])
        
        state["messages"] = state["messages"] + [formatted_response]
        state["context"]["final_response"] = formatted_response.content
        
        logger.info("response_formatted")
        
        return state
    
    def should_continue(self, state: AgentState) -> str:
        """Determine if we should continue or end"""
        last_message = state["messages"][-1]
        
        # If there are tool calls, continue to act
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            if state["iteration_count"] >= state["max_iterations"]:
                logger.warning("max_iterations_reached", count=state["iteration_count"])
                return "end"
            return "continue"
        
        # Otherwise, we're done
        return "end"
    
    def _build_system_message(self, state: AgentState) -> SystemMessage:
        """Build system message with context and domain knowledge"""
        intent = state.get("intent", "GENERAL_CHAT")
        
        system_prompt = f"""You are an expert real estate assistant with access to comprehensive property data, market analytics, and risk assessment tools.

**Current Intent**: {intent}

**Your Capabilities:**
1. **Property Search**: Query Supabase for property listings using query_supabase tool
2. **Market Analysis**: Query BigQuery for market trends using query_bigquery tool
3. **Geocoding**: Convert locations to coordinates using geocode_location tool
4. **Distance Calculations**: Find properties near specific locations
5. **Risk Assessment**: Analyze disaster risk using FEMA NRI data
6. **Investment Analysis**: Combine risk, market, and prediction data
7. **Web Search**: Get current information using search_web tool
8. **Agent Finder**: Direct users to agent finder using find_real_estate_agents tool

**Important Rules:**
- NEVER query or mention: profiles, user_favorites, users, sessions, auth tables
- For agent recommendations, ALWAYS use find_real_estate_agents tool
- Use query_supabase for: properties, nri_counties, uszips, gis.us_counties
- Use query_bigquery for: market data, predictions, trends
- Geocode locations when users mention landmarks, universities, or addresses
- Combine multiple tools for comprehensive answers
- Always format responses clearly with prices, addresses, and key details

**Domain Knowledge:**

## SUPABASE TABLES
{SUPABASE_DOMAIN_KNOWLEDGE[:2000]}

## BIGQUERY TABLES
{BIGQUERY_DOMAIN_KNOWLEDGE[:2000]}

**Response Style:**
- Be conversational and helpful
- Present information clearly with formatting
- Include specific numbers, prices, and locations
- Provide actionable recommendations
- Offer to search more or adjust criteria

Now help the user with their query using the appropriate tools."""
        
        return SystemMessage(content=system_prompt)
    
    async def run_async(self, query: str, session_id: str, history: List[Dict] = None) -> Dict[str, Any]:
        """Run the agent asynchronously"""
        return await self._run(query, session_id, history)
    
    def run(self, query: str, session_id: str, history: List[Dict] = None) -> Dict[str, Any]:
        """Run the agent synchronously"""
        logger.info("agent_run_started", query=query, session_id=session_id)
        
        # Convert history to messages
        messages = []
        if history:
            for msg in history[-10:]:  # Last 10 messages for context
                if msg["role"] == "user":
                    messages.append(HumanMessage(content=msg["content"]))
                elif msg["role"] == "assistant":
                    messages.append(AIMessage(content=msg["content"]))
        
        # Add current query
        messages.append(HumanMessage(content=query))
        
        # Initialize state
        initial_state = AgentState(
            messages=messages,
            user_query=query,
            session_id=session_id,
            intent="",
            requires_sql=False,
            requires_geocoding=False,
            requires_web_search=False,
            context={
                "start_time": datetime.now().isoformat()
            },
            iteration_count=0,
            max_iterations=10
        )
        
        try:
            # Run workflow
            final_state = self.app.invoke(initial_state)
            
            # Extract final response
            final_response = final_state["context"].get("final_response", "")
            if not final_response:
                # Fallback to last AI message
                for msg in reversed(final_state["messages"]):
                    if isinstance(msg, AIMessage):
                        final_response = msg.content
                        break
            
            logger.info("agent_run_completed", 
                       iterations=final_state["iteration_count"],
                       intent=final_state["intent"])
            
            return {
                "success": True,
                "response": final_response,
                "intent": final_state["intent"],
                "iterations": final_state["iteration_count"],
                "context": final_state["context"]
            }
            
        except Exception as e:
            logger.error("agent_run_error", error=str(e), query=query)
            return {
                "success": False,
                "error": str(e),
                "response": "I apologize, but I encountered an error processing your request. Please try rephrasing your question."
            }


# Global agent instance
agent = ReActAgent()
