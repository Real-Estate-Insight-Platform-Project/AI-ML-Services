"""
Tool Implementations for Agentic Real Estate Assistant
Includes: Geocoding, Web Search, SQL Agents, Distance Calculator
"""
import re
import json
import requests
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from decimal import Decimal
import uuid

from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SQLAlchemyError
from google.cloud import bigquery
from geopy.distance import geodesic
from langchain_core.tools import tool
import structlog

from src.config import settings, ALLOWED_SUPABASE_TABLES, ALLOWED_BIGQUERY_TABLES, PROTECTED_TABLES
from src.agents.supabase_domain import SUPABASE_DOMAIN_KNOWLEDGE
from src.agents.bigquery_domain import BIGQUERY_DOMAIN_KNOWLEDGE

logger = structlog.get_logger()


# ==================== DATABASE CLIENTS ====================

class DatabaseClients:
    """Singleton class for managing database connections"""
    
    _instance = None
    _supabase_engine = None
    _bigquery_client = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @property
    def supabase_engine(self):
        if self._supabase_engine is None:
            self._supabase_engine = create_engine(
                settings.supabase_url,
                pool_pre_ping=True,
                pool_size=settings.db_pool_size,
                max_overflow=settings.db_max_overflow,
                pool_recycle=settings.db_pool_recycle,
                connect_args={"options": "-c statement_timeout=30000"}
            )
            logger.info("supabase_engine_initialized")
        return self._supabase_engine
    
    @property
    def bigquery_client(self):
        if self._bigquery_client is None:
            try:
                self._bigquery_client = bigquery.Client(
                    project=settings.bq_project_id,
                    location=settings.bq_location
                )
                logger.info("bigquery_client_initialized", project=settings.bq_project_id)
            except Exception as e:
                logger.error("bigquery_initialization_failed", error=str(e))
                raise
        return self._bigquery_client


db_clients = DatabaseClients()


# ==================== UTILITY FUNCTIONS ====================

def convert_for_json(obj: Any) -> Any:
    """Convert objects to JSON-serializable format"""
    if obj is None:
        return None
    elif isinstance(obj, (str, int, float, bool)):
        return obj
    elif isinstance(obj, uuid.UUID):
        return str(obj)
    elif isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {str(k): convert_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [convert_for_json(item) for item in obj]
    else:
        try:
            return str(obj)
        except Exception:
            return f"<unserializable {type(obj).__name__}>"


def sanitize_sql_query(query: str, database: str = "supabase") -> Optional[str]:
    """
    Sanitize SQL query for security
    Returns None if query is unsafe
    """
    try:
        query = query.strip()
        query_upper = query.upper()
        
        # Security checks
        dangerous_patterns = [
            r'\bDROP\b', r'\bDELETE\b', r'\bTRUNCATE\b', r'\bINSERT\b',
            r'\bUPDATE\b', r'\bALTER\b', r'\bCREATE\b', r'\bGRANT\b',
            r'\bREVOKE\b', r'\bEXECUTE\b', r'\bEXEC\b', r'\b--\b', r'/\*', r'\*/',
            r';.*SELECT', r';.*DELETE', r';.*DROP'
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, query_upper):
                logger.warning("dangerous_sql_pattern_detected", pattern=pattern, query=query)
                return None
        
        # Check for protected tables
        for protected_table in PROTECTED_TABLES:
            pattern = r'\b' + re.escape(protected_table.upper()) + r'\b'
            if re.search(pattern, query_upper):
                logger.warning("protected_table_access_attempt", table=protected_table)
                return None
        
        # Must be SELECT query
        if not query_upper.startswith('SELECT'):
            logger.warning("non_select_query_attempt", query=query)
            return None
        
        # Add LIMIT if not present
        if "LIMIT" not in query_upper:
            query = query.rstrip(';') + f" LIMIT {settings.max_query_results}"
        
        return query
        
    except Exception as e:
        logger.error("query_sanitization_error", error=str(e))
        return None


# ==================== GEOCODING TOOLS ====================

def _geocode_census(place: str) -> Optional[Dict[str, Any]]:
    """Geocode using US Census Geocoder (no API key required)"""
    try:
        url = "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress"
        params = {
            "address": place,
            "benchmark": "Public_AR_Current",
            "format": "json"
        }
        response = requests.get(url, params=params, timeout=8)
        response.raise_for_status()
        data = response.json()
        
        matches = data.get("result", {}).get("addressMatches", [])
        if matches:
            best = matches[0]
            coords = best.get("coordinates", {})
            lat = coords.get("y")
            lon = coords.get("x")
            if lat is not None and lon is not None:
                return {
                    "lat": float(lat),
                    "lon": float(lon),
                    "formatted_address": best.get("matchedAddress", place),
                    "source": "census"
                }
    except Exception as e:
        logger.warning("census_geocoding_failed", place=place, error=str(e))
    return None


def _geocode_nominatim(place: str) -> Optional[Dict[str, Any]]:
    """Geocode using Nominatim (OpenStreetMap)"""
    try:
        url = "https://nominatim.openstreetmap.org/search"
        params = {"q": place, "format": "json", "limit": 1}
        headers = {"User-Agent": settings.geocoding_user_agent}
        response = requests.get(url, params=params, headers=headers, timeout=8)
        response.raise_for_status()
        results = response.json()
        
        if isinstance(results, list) and results:
            result = results[0]
            return {
                "lat": float(result["lat"]),
                "lon": float(result["lon"]),
                "formatted_address": result.get("display_name", place),
                "source": "nominatim"
            }
    except Exception as e:
        logger.warning("nominatim_geocoding_failed", place=place, error=str(e))
    return None


@tool
def geocode_location(place: str) -> Dict[str, Any]:
    """
    Geocode a location to get latitude and longitude coordinates.
    
    Args:
        place: Location string (e.g., "Boston University", "123 Main St, Boston MA", "Central Park")
    
    Returns:
        Dictionary with lat, lon, formatted_address, and source
    """
    if not place or not place.strip():
        return {"error": "Place name is required", "success": False}
    
    logger.info("geocoding_request", place=place)
    
    # Try Census first (US-focused, free)
    result = _geocode_census(place.strip())
    if result:
        logger.info("geocoding_success", place=place, source="census")
        return {"success": True, **result}
    
    # Fallback to Nominatim (global coverage)
    result = _geocode_nominatim(place.strip())
    if result:
        logger.info("geocoding_success", place=place, source="nominatim")
        return {"success": True, **result}
    
    logger.warning("geocoding_failed", place=place)
    return {
        "error": f"Could not geocode location: {place}",
        "success": False
    }


@tool
def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> Dict[str, Any]:
    """
    Calculate distance in miles between two coordinates.
    
    Args:
        lat1: Latitude of first point
        lon1: Longitude of first point
        lat2: Latitude of second point
        lon2: Longitude of second point
    
    Returns:
        Dictionary with distance in miles and kilometers
    """
    try:
        distance_miles = geodesic((lat1, lon1), (lat2, lon2)).miles
        distance_km = geodesic((lat1, lon1), (lat2, lon2)).kilometers
        
        return {
            "success": True,
            "distance_miles": round(distance_miles, 2),
            "distance_km": round(distance_km, 2)
        }
    except Exception as e:
        logger.error("distance_calculation_error", error=str(e))
        return {"error": str(e), "success": False}


# ==================== SQL AGENT TOOLS ====================

@tool
def query_supabase(sql_query: str) -> Dict[str, Any]:
    """
    Execute SQL query on Supabase (PostgreSQL with PostGIS).
    
    Use for:
    - Property listings (properties table)
    - Risk assessment data (nri_counties table)
    - ZIP code data (uszips table)
    - Spatial queries with PostGIS
    
    Tables available: properties, nri_counties, uszips, gis.us_counties
    
    Args:
        sql_query: SELECT query to execute
    
    Returns:
        Dictionary with rows, count, and query information
    
    Examples:
        query_supabase("SELECT * FROM properties WHERE city = 'Boston' LIMIT 10")
        query_supabase("SELECT * FROM nri_counties WHERE risk_index_rating = 'Very Low' LIMIT 20")
    """
    logger.info("supabase_query_request", query=sql_query)
    
    # Sanitize query
    safe_query = sanitize_sql_query(sql_query, database="supabase")
    if not safe_query:
        return {
            "error": "Query failed security validation",
            "allowed_tables": ALLOWED_SUPABASE_TABLES,
            "success": False
        }
    
    try:
        with db_clients.supabase_engine.connect() as conn:
            result = conn.execute(text(safe_query))
            rows = result.fetchall()
            raw_rows = [dict(row._mapping) for row in rows]
            json_rows = [convert_for_json(row) for row in raw_rows]
            
            logger.info("supabase_query_success", count=len(json_rows))
            
            return {
                "success": True,
                "rows": json_rows,
                "count": len(json_rows),
                "query": safe_query
            }
            
    except SQLAlchemyError as e:
        logger.error("supabase_query_error", error=str(e), query=safe_query)
        return {
            "error": f"Database error: {str(e)}",
            "query": sql_query,
            "success": False
        }


@tool
def query_bigquery(sql_query: str) -> Dict[str, Any]:
    """
    Execute SQL query on BigQuery for market data and predictions.
    
    Use for:
    - Historical market statistics (county_market, state_market)
    - Future predictions (county_predictions, state_predictions)
    - Reference data (county_lookup, state_lookup)
    
    Tables available: county_market, county_predictions, state_market, state_predictions, county_lookup, state_lookup
    
    Args:
        sql_query: SELECT query to execute (Standard SQL)
    
    Returns:
        Dictionary with rows, count, and query information
    
    Examples:
        query_bigquery("SELECT * FROM county_market WHERE year = 2025 LIMIT 10")
        query_bigquery("SELECT * FROM county_predictions WHERE buyer_friendly = 1 LIMIT 20")
    """
    logger.info("bigquery_query_request", query=sql_query)
    
    # Sanitize query
    safe_query = sanitize_sql_query(sql_query, database="bigquery")
    if not safe_query:
        return {
            "error": "Query failed security validation",
            "allowed_tables": ALLOWED_BIGQUERY_TABLES,
            "success": False
        }
    
    try:
        # Add fully qualified table names if not present
        processed_query = safe_query
        if settings.bigquery_dataset_full not in processed_query:
            for table in ALLOWED_BIGQUERY_TABLES:
                pattern = r'(?<!\w\.)(?<!\.)' + re.escape(table) + r'(?!\w)'
                replacement = f"`{settings.bigquery_dataset_full}.{table}`"
                processed_query = re.sub(
                    pattern,
                    replacement,
                    processed_query,
                    flags=re.IGNORECASE
                )
        
        logger.info("bigquery_executing", processed_query=processed_query)
        
        query_job = db_clients.bigquery_client.query(processed_query)
        results = query_job.result()
        rows = [convert_for_json(dict(row)) for row in results]
        
        logger.info("bigquery_query_success", count=len(rows))
        
        return {
            "success": True,
            "rows": rows,
            "count": len(rows),
            "query": processed_query
        }
        
    except Exception as e:
        logger.error("bigquery_query_error", error=str(e), query=safe_query)
        return {
            "error": f"BigQuery error: {str(e)}",
            "query": sql_query,
            "success": False
        }


# ==================== WEB SEARCH TOOL ====================

@tool
def search_web(query: str, num_results: int = 5) -> Dict[str, Any]:
    """
    Search the web for current information.
    
    Use for:
    - Current market trends not in database
    - Recent news about real estate markets
    - Economic indicators affecting housing
    - Neighborhood information
    
    Args:
        query: Search query string
        num_results: Number of results to return (default 5, max 10)
    
    Returns:
        Dictionary with search results including titles, snippets, and URLs
    """
    # Placeholder implementation - integrate with your preferred search API
    # Options: Google Custom Search, Bing Search API, SerpAPI, etc.
    
    logger.info("web_search_request", query=query, num_results=num_results)
    
    # This is a placeholder - implement with actual search API
    return {
        "success": True,
        "query": query,
        "results": [
            {
                "title": "Web search placeholder",
                "snippet": "Integrate with Google Custom Search, Bing, or SerpAPI for actual results",
                "url": "https://example.com"
            }
        ],
        "message": "Web search tool needs API integration. Configure Google Custom Search or alternative search API."
    }


# ==================== INVESTMENT ANALYSIS TOOL ====================

@tool
def analyze_investment_potential(
    location: Optional[str] = None,
    max_price: Optional[float] = None,
    min_beds: Optional[int] = None
) -> Dict[str, Any]:
    """
    Analyze investment potential combining risk data, market trends, and predictions.
    
    Args:
        location: City or county name (optional)
        max_price: Maximum property price (optional)
        min_beds: Minimum bedrooms (optional)
    
    Returns:
        Investment analysis with risk scores, market trends, and recommendations
    """
    logger.info("investment_analysis_request", location=location)
    
    try:
        analysis = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "criteria": {
                "location": location,
                "max_price": max_price,
                "min_beds": min_beds
            },
            "recommendations": []
        }
        
        # Get low-risk counties from Supabase
        risk_query = """
            SELECT county_fips, county_name, state_name, 
                   risk_index_score, risk_index_rating, predominant_hazard
            FROM nri_counties
            WHERE risk_index_rating IN ('Very Low', 'Relatively Low')
            ORDER BY risk_index_score ASC
            LIMIT 20
        """
        
        risk_result = query_supabase.invoke({"sql_query": risk_query})
        
        if risk_result.get("success"):
            low_risk_counties = risk_result.get("rows", [])
            analysis["low_risk_counties_count"] = len(low_risk_counties)
            analysis["low_risk_counties_sample"] = low_risk_counties[:5]
        
        # Get buyer-friendly predictions from BigQuery
        prediction_query = """
            SELECT cl.county_name, sl.state_id,
                   cp.median_listing_price_forecast,
                   cp.market_trend
            FROM `fourth-webbing-474805-j5.real_estate_market.county_predictions` cp
            JOIN `fourth-webbing-474805-j5.real_estate_market.county_lookup` cl 
              ON cp.county_num = cl.county_num
            JOIN `fourth-webbing-474805-j5.real_estate_market.state_lookup` sl 
              ON cl.state_num = sl.state_num
            WHERE cp.year = 2025 AND cp.month = 11
              AND cp.buyer_friendly = 1
            ORDER BY cp.median_listing_price_forecast ASC
            LIMIT 20
        """
        
        prediction_result = query_bigquery.invoke({"sql_query": prediction_query})
        
        if prediction_result.get("success"):
            buyer_markets = prediction_result.get("rows", [])
            analysis["buyer_friendly_markets_count"] = len(buyer_markets)
            analysis["buyer_friendly_markets_sample"] = buyer_markets[:5]
        
        return analysis
        
    except Exception as e:
        logger.error("investment_analysis_error", error=str(e))
        return {
            "error": str(e),
            "success": False
        }


# ==================== AGENT FINDER REDIRECT TOOL ====================

@tool
def find_real_estate_agents(location: str) -> Dict[str, Any]:
    """
    Direct users to the real estate agent finder portal.
    
    Args:
        location: Location where user needs an agent
    
    Returns:
        Information about agent finder portal with link
    """
    logger.info("agent_finder_request", location=location)
    
    return {
        "success": True,
        "message": "For real estate agent recommendations, please visit our agent finder portal.",
        "agent_finder_url": settings.agent_finder_url,
        "location": location,
        "instructions": "Use our agent finder tool to connect with top-rated local agents."
    }


# Export all tools
TOOLS = [
    geocode_location,
    calculate_distance,
    query_supabase,
    query_bigquery,
    search_web,
    analyze_investment_potential,
    find_real_estate_agents,
]
